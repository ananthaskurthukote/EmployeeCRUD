import { Employee } from './../../shared/employee.model';
import { EmployeeService } from './../../shared/employee.service';
import { Component, OnInit } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  lists: Employee[];
  constructor(private service: EmployeeService,
    private firestore: AngularFirestore,
    private toast: ToastrService
  ) { }

  ngOnInit() {
    this.service.getEmployees().subscribe(actionArray => {
      this.lists = actionArray.map(item => {
        return {
          id: item.payload.doc.id,
          ...item.payload.doc.data()
        } as Employee
      })
    })
  }

  onEdit(emp: Employee) {
    this.service.formData = Object.assign({}, emp);
  }

  onDelete(id) {
    if (confirm("Are you sure?")) {
      this.firestore.collection("records").doc(id).delete();
      this.toast.warning("Deleted successfully", "EMP. Register");
    }
  }

}
