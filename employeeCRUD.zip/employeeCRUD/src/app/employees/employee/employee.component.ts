import { ToastrService } from 'ngx-toastr';
import { NgForm } from '@angular/forms';
import { EmployeeService } from './../../shared/employee.service';
import { Component, OnInit } from '@angular/core';
import { AngularFirestore } from '@angular/fire/firestore';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  constructor(private service: EmployeeService,
    private firestore: AngularFirestore,
    public toast: ToastrService
  ) { }

  ngOnInit() {
    this.resetForm();
  }

  resetForm(form?: NgForm) {
    if (form != null)
      form.resetForm();
    this.service.formData = {
      id: null,
      fullName: '',
      empCode: '',
      position: '',
      mobile: ''
    }
  }

  onSubmit(form: NgForm) {
    console.log("Onsubmit fired");
    let data = Object.assign({}, form.value);
    delete data.id;
    if (form.value.id == null) {
      this.firestore.collection("records").add(data).then(function () {
        console.log("Data updated");
      }).catch(e => {
        console.log("Error" + e);
      });
      this.toast.success("Submitted Successfully", "EMP. Register");
    }
    else {
      this.firestore.collection("records").doc(form.value.id).update(data);
      this.toast.success("Updated Successfully", "EMP. Register");
    }
    form.resetForm();
  }

}
